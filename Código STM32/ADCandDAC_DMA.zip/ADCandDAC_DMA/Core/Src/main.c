/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#define ARM_MATH_CM4
#include "math.h"
#include "arm_math.h"
#include "stdio.h"
#include "i2c-lcd.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define Fs 96000.0f
#define MAX_DELAY 9600    // Using sampling in 96Khz we have 1s of Delay time.
#define MAX_DELAY_Flg 480
#define threshold 62500000.0f

// Distorção para áudio: 62500000.0f
// DIstorção para Teste Senoide: 250000000.0f
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
I2C_HandleTypeDef hi2c1;
I2S_HandleTypeDef hi2s2;
DMA_HandleTypeDef hdma_i2s2_ext_rx;
DMA_HandleTypeDef hdma_spi2_tx;

/* USER CODE BEGIN PV */
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
static void MX_I2S2_Init(void);
static void MX_I2C1_Init(void);
/* USER CODE BEGIN PFP */
// Funções do Menu
void text_effct(char *txt, uint8_t n);
void text_prm(char *txt, int8_t r, int8_t c, int8_t num);
int8_t encoder_cnt(int8_t prm, int8_t prm_mx);

// Efeitos
int effects(float32_t sample);
float32_t distortion(float32_t sample);
float32_t echo(float32_t sample);
float32_t tremolo(float32_t sample);
float32_t flanger(float32_t sample);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
// Buffers de recepção e transmissão de dados
uint16_t rxBuf[8];
uint16_t txBuf[8];
float32_t yout, youtFx = 0, y_lp = 0, y_1 = 0, x_1 = 0;
// flags para navegação no menu e leitura de botões
uint8_t flag = 0, flag_enc = 0, menu = 0, count = 0, effect = 0, prm = 0, prm_mx = 0, n1 = 0, n2 = 0;
GPIO_PinState State = GPIO_PIN_RESET, LastState = GPIO_PIN_RESET;
// Parâmetros dos efeitos
float32_t vol = 0.5;
uint8_t glb_lv = 99;
uint8_t flg_gn = 50, dst_gn = 50, ech_gn = 70;
uint8_t ech_dp = 80, trm_dp = 80;
uint8_t flg_fq = 40, trm_fq = 50;

//Echo
float32_t buffer[MAX_DELAY];
uint16_t oldest = 0; /* index for  delay effect buffer value */

//Tremolo
float32_t trgWave_trm = 0;
int8_t inc_trm = 1;

//Flanger
float32_t BufferFlg[MAX_DELAY_Flg];
float32_t trgWave_flg = 0;
int8_t inc_flg = 1;
uint16_t oldestFlg = 0, currentFlg = 0, Dint = 0;



/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_I2S2_Init();
  MX_I2C1_Init();
  /* USER CODE BEGIN 2 */
  lcd_init();
  HAL_I2SEx_TransmitReceive_DMA (&hi2s2, txBuf, rxBuf, 4);
  LastState = HAL_GPIO_ReadPin(GPIOE, GPIO_PIN_7);

  lcd_put_cur(0, 0);
  lcd_send_string ("Inicializando...");
  HAL_Delay(500);
  lcd_put_cur(1, 0);
  lcd_send_string ("PedalBoard V1");
  HAL_Delay(1500);
  lcd_clear();
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */

	// Seleção de efeitos
	vol = (0.005)*glb_lv;
	if (menu == 0){
		prm = 0;
		effect = encoder_cnt(effect, 4);
		// Catálogo de efeitos
		switch (effect) {
		case 0:
			text_effct("Clean       >", effect);
			prm_mx = 0;
			break;
		case 1:
			text_effct("Distortion <>", effect);
			prm_mx = 2;
			break;
		case 2:
			text_effct("Delay      <>", effect);
			prm_mx = 3;
			break;
		case 3:
			text_effct("Tremolo    <>", effect);
			prm_mx = 3;
			break;
		case 4:
			text_effct("Flanger     <", effect);
			prm_mx = 3;
			break;
		}

		count++;
		if (count > 10){
			count = 0;
			if ((HAL_GPIO_ReadPin(GPIOE, GPIO_PIN_10)) && (flag == 0)) { // Botão de ajuste de efeito
				flag = 1;
				menu = 1;
			} else if (!HAL_GPIO_ReadPin(GPIOE, GPIO_PIN_10)) {
				if ((HAL_GPIO_ReadPin(GPIOE, GPIO_PIN_12)) && (flag == 0)) { // Botão que define o efeito, até 3 efeitos
					flag = 1;
					if (n1 == 0 && n2 == 0) {
						n1 = effect;
					} else if (n1 == effect) {
						n1 = 0;
					} else if (n2 == 0 && n1 != 0) {
						n2 = effect;
					} else if (n2 == effect) {
						n2 = 0;
					}
				} else if (!HAL_GPIO_ReadPin(GPIOE, GPIO_PIN_12)) {
					flag = 0;
				}
			}
		}

	}

	// Seleção de parâmetros
	if (menu == 1){
		switch (effect) {
		case 0:
			glb_lv = encoder_cnt(glb_lv, 99);
			text_prm("Lv:", 1, 0, glb_lv);
			break;
		case 1:
			if (prm == 0) {
				glb_lv = encoder_cnt(glb_lv, 99);
				text_prm("Lv:", 1, 0, glb_lv);
			} else {
				dst_gn = encoder_cnt(dst_gn, 99);
				text_prm("Gn:", 1, 0, dst_gn);
			}
			break;
		case 2:
			if (prm == 0) {
				glb_lv = encoder_cnt(glb_lv, 99);
				text_prm("Lv:", 1, 0, glb_lv);
			} else if (prm == 1){
				ech_gn = encoder_cnt(ech_gn, 99);
				text_prm("Gn:", 1, 0, ech_gn);
			} else {
				ech_dp = encoder_cnt(ech_dp, 99);
				text_prm("Dp:", 1, 0, ech_dp);
			}
			break;
		case 3:
			if (prm == 0) {
				glb_lv = encoder_cnt(glb_lv, 99);
				text_prm("Lv:", 1, 0, glb_lv);
			} else if (prm == 1){
				trm_dp = encoder_cnt(trm_dp, 99);
				text_prm("Dp:", 1, 0, trm_dp);
			} else {
				trm_fq = encoder_cnt(trm_fq, 99);
				text_prm("Fq:", 1, 0, trm_fq);
			}
			break;
		case 4:
			if (prm == 0) {
				glb_lv = encoder_cnt(glb_lv, 99);
				text_prm("Lv:", 1, 0, glb_lv);
			}else if (prm == 1){
				flg_gn = encoder_cnt(flg_gn, 99);
				text_prm("Gn:", 1, 0, flg_gn);
			} else {
				flg_fq = encoder_cnt(flg_fq, 99);
				text_prm("Fq:", 1, 0, flg_fq);
			}
			break;
		}

		count++;
		if (count >= 10){
			count = 0;
			if ((HAL_GPIO_ReadPin(GPIOE, GPIO_PIN_10)) && (flag == 0)) { // Botão de ajuste de efeito
				flag = 1;
				menu = 0;
				lcd_clear();
			} else if (!HAL_GPIO_ReadPin(GPIOE, GPIO_PIN_10)) {
				if ((!HAL_GPIO_ReadPin(GPIOE, GPIO_PIN_9)) && (flag == 0)) { // botão do Encoder (SW)
					flag = 1;
					if (prm < prm_mx) {
						prm++;
					} else {
						prm = 0;
					}
				} else if (HAL_GPIO_ReadPin(GPIOE, GPIO_PIN_9)) {
					flag = 0;
				}
			}
		}
	}

  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 4;
  RCC_OscInitStruct.PLL.PLLN = 168;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief I2C1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C1_Init(void)
{

  /* USER CODE BEGIN I2C1_Init 0 */

  /* USER CODE END I2C1_Init 0 */

  /* USER CODE BEGIN I2C1_Init 1 */

  /* USER CODE END I2C1_Init 1 */
  hi2c1.Instance = I2C1;
  hi2c1.Init.ClockSpeed = 100000;
  hi2c1.Init.DutyCycle = I2C_DUTYCYCLE_2;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C1_Init 2 */

  /* USER CODE END I2C1_Init 2 */

}

/**
  * @brief I2S2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2S2_Init(void)
{

  /* USER CODE BEGIN I2S2_Init 0 */

  /* USER CODE END I2S2_Init 0 */

  /* USER CODE BEGIN I2S2_Init 1 */

  /* USER CODE END I2S2_Init 1 */
  hi2s2.Instance = SPI2;
  hi2s2.Init.Mode = I2S_MODE_MASTER_TX;
  hi2s2.Init.Standard = I2S_STANDARD_PHILIPS;
  hi2s2.Init.DataFormat = I2S_DATAFORMAT_24B;
  hi2s2.Init.MCLKOutput = I2S_MCLKOUTPUT_ENABLE;
  hi2s2.Init.AudioFreq = I2S_AUDIOFREQ_96K;
  hi2s2.Init.CPOL = I2S_CPOL_LOW;
  hi2s2.Init.ClockSource = I2S_CLOCK_PLL;
  hi2s2.Init.FullDuplexMode = I2S_FULLDUPLEXMODE_ENABLE;
  if (HAL_I2S_Init(&hi2s2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2S2_Init 2 */

  /* USER CODE END I2S2_Init 2 */

}

/**
  * Enable DMA controller clock
  */
static void MX_DMA_Init(void)
{

  /* DMA controller clock enable */
  __HAL_RCC_DMA1_CLK_ENABLE();

  /* DMA interrupt init */
  /* DMA1_Stream3_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Stream3_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA1_Stream3_IRQn);
  /* DMA1_Stream4_IRQn interrupt configuration */
  //HAL_NVIC_SetPriority(DMA1_Stream4_IRQn, 0, 0); // Comenta essas linhas para evitar que a interrupção de saída (DAC) atrapalhe
  //HAL_NVIC_EnableIRQ(DMA1_Stream4_IRQn);

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOE_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();

  /*Configure GPIO pins : PE7 PE8 PE9 PE10
                           PE11 PE12 */
  GPIO_InitStruct.Pin = GPIO_PIN_7|GPIO_PIN_8|GPIO_PIN_9|GPIO_PIN_10
                          |GPIO_PIN_11|GPIO_PIN_12;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOE, &GPIO_InitStruct);

}

/* USER CODE BEGIN 4 */

// Funções de tratamento do áuido

// Leitura do sinal de áudio
void HAL_I2SEx_TxRxHalfCpltCallback(I2S_HandleTypeDef *hi2s)
{
	// Restaura a amostra de 24 bit sinalizada a partir dos buffers de 16 bit
	int lSample = (int) (rxBuf[0]<<16)|rxBuf[1];
	int rSample = (int) (rxBuf[2]<<16)|rxBuf[3];

	// Divide as amostra por 2 -> -3dB por amostra
	lSample = lSample>>1;
	rSample = rSample>>1;

	y_lp = (0.9366f)*y_1 + (0.0634f)*x_1;
	x_1 = rSample + lSample;
	y_1 = y_lp;

	// Soma as amostra para uma saída mono. O valor de 0.85 garante uma relação 1:1 entre saída e entrada
	youtFx = effects ((y_lp)); // Ajuste de volume, comum a todos os efeitos

	// Restaura o buffer para transmissão
	txBuf[0] = ((int) youtFx>>16)&0xFFFF;
	txBuf[1] = (int) youtFx&0xFFFF;
	txBuf[2] = ((int) youtFx>>16)&0xFFFF;
	txBuf[3] = (int) youtFx&0xFFFF;
}

void HAL_I2SEx_TxRxCpltCallback(I2S_HandleTypeDef *hi2s)
{
	// Restaura a amostra de 24 bit sinalizada a partir dos buffers de 16 bit
	int lSample = (int) (rxBuf[4]<<16)|rxBuf[5];
	int rSample = (int) (rxBuf[6]<<16)|rxBuf[7];

	// Divide as amostra por 2 -> -3dB por amostra
	lSample = lSample>>1;
	rSample = rSample>>1;

	y_lp = (0.9366f)*y_1 + (0.0634f)*x_1;
	x_1 = rSample + lSample;
	y_1 = y_lp;

	// Soma as amostra para uma saída mono. O valor de 0.85 garante uma relação 1:1 entre saída e entrada
	youtFx = effects ((y_lp)); // Ajuste de volume, comum a todos os efeitos

	// Restaura o buffer para transmissão
	txBuf[4] = ((int) youtFx>>16)&0xFFFF;
	txBuf[5] = (int) youtFx&0xFFFF;
	txBuf[6] = ((int) youtFx>>16)&0xFFFF;
	txBuf[7] = (int) youtFx&0xFFFF;
}

// Seleção de Efeitos
int effects (float32_t sample) {
	if (n1 == 1 || n2 == 1){
		sample = distortion(sample);
	}
	if (n1 == 2 || n2 == 2){
		sample = echo(sample);
	}
	if (n1 == 3 || n2 == 3){
		sample = tremolo(sample);
	}
	if (n1 == 4 || n2 == 4){
		sample = flanger(sample);
	}

	return sample*(vol); //(0.005*glb_lv)*
}


// Efeitos
float32_t distortion (float32_t sample) {
	float32_t gain = 1 + (0.02*dst_gn);

	if ((gain*sample) > threshold){
		yout = threshold;
	} else if ((gain*sample) < -threshold){
		yout = -threshold;
	} else {
		yout = gain*sample;
	}

	return yout;
}


float32_t echo(float32_t sample){
	float32_t delayed = buffer[oldest];
	uint16_t delayDP = ((MAX_DELAY * (ech_dp + 1))/100);
	float32_t alpha = (0.01*ech_gn);

	yout = (sample + (alpha * delayed));

	buffer[oldest] = sample;
	if (oldest++ >= delayDP) {
		oldest = 0;
	}

	return yout;
}


float32_t tremolo(float32_t sample){
	float32_t freq =  (0.1*trm_fq);  // 0 a 10Hz
	float32_t alpha = (0.01*trm_dp); // 0 a 1

	trgWave_trm = trgWave_trm + inc_trm*((2*freq)/Fs);
	if(trgWave_trm >= 1 && inc_trm == 1){
		inc_trm = -1;
	}else if(trgWave_trm <= 0){
		inc_trm = 1;
	}

	yout = sample*(1.0f - (alpha*trgWave_trm));

	return yout;
}


float32_t flanger(float32_t sample){
	float32_t freq =  (0.05*flg_fq); // 0 a 5Hz
	float32_t alpha = (0.01*flg_gn); // 0 a 1

	BufferFlg[oldestFlg] = sample;
	oldestFlg = (oldestFlg + 1);
	if (oldestFlg >= MAX_DELAY_Flg){
		oldestFlg = 0;
	}

	Dint = MAX_DELAY_Flg*trgWave_flg;

	trgWave_flg = trgWave_flg + inc_flg*((2*freq)/Fs);
	if(trgWave_flg >= 1 && inc_flg == 1){
		inc_flg = -1;
	}else if(trgWave_flg <= 0){
		inc_flg = 1;
	}

	currentFlg = (oldestFlg + MAX_DELAY_Flg - Dint)%MAX_DELAY_Flg;
	yout = sample + (alpha*BufferFlg[currentFlg]);

	return yout;
}


// Funções do LCD

void text_effct(char *txt, uint8_t n){
	lcd_put_cur(0, 0);
	lcd_send_string("Fx:");
	lcd_put_cur(0, 3);
	lcd_send_string (txt);
	lcd_put_cur(1, 0);
	if (n1 == n || n2 == n) {
		lcd_send_string ("OK to select - x");
	} else {
		lcd_send_string ("OK to select - o");
	}
}

void text_prm(char *txt, int8_t r, int8_t c, int8_t num){
	int dezena = num / 10;
	int unidade = num % 10;
	char crtDezena = '0' + dezena;
	char crtUnidade = '0' + unidade;

	lcd_put_cur(r, c);
	lcd_send_string(txt);
	lcd_put_cur(r, c+3);
	lcd_send_data(crtDezena);
	lcd_put_cur(r, c+4);
	lcd_send_data(crtUnidade);
	lcd_put_cur(r, c+6);
	lcd_send_string("         ");
}

// Funções de controle do Encoder
int8_t encoder_cnt(int8_t prm, int8_t prm_mx){

	State = HAL_GPIO_ReadPin(GPIOE, GPIO_PIN_7);
	if ((State != LastState) && (!State)){
		// Se o estado do DT for diferente do estado do CK, isso significa que o Encoder está girando no sentido horário
		if (HAL_GPIO_ReadPin(GPIOE, GPIO_PIN_8) != State) {
			if (prm < prm_mx){
				prm++;
			}
		} else {
			if (prm > 0){
				prm--;
			}
		}
	}
	LastState = State; // Atualiza o estado anterior do CK com o estado atual

	return prm;
}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
